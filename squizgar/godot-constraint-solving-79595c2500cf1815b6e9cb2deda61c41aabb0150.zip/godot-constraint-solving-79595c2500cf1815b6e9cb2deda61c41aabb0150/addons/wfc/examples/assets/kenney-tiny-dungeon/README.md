Tileset from [Kenny](https://kenney.nl/assets/tiny-dungeon).
